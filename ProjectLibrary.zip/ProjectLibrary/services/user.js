'use strict';
const mysql = require('mysql');

//con establishment

var con = mysql.createConnection({
    host:'localhost',
    port:'3306',
    user:'root',
    password:'Root1234',
    database:'libraryDB'
});

con.connect((err)=>{
    // if(err) throw err;
    if(err) console.dir("ERROR: Couldnt connect to db-- "+err.message);
    else console.dir("Connected to Database...")
});



//services -- user.js -- only business logics should be written in this.

async function getUserById(userId){  //this should probably be/return promise --yup

     return new Promise((resolve, reject)=>{
        let sql = `SELECT * from users WHERE id='${ userId }'`;
        let query = con.query(sql, (err, result)=>{
            // if(err) throw err;
            if (err){
                reject(err);
            }
            // console.log(`RESULTS: USER with id ${req.params.id} fetched  and sent to client`);
  //uncomment if not testing          // console.log(`RESULTS: USER with id ${userId} fetched  and sent to client`);
    //uncomment if not testing          // console.dir("Total records fetched: "+result.length); 
            /* if(result.length === 0){
                res.send("No any USER exists with <mark> &nbsp; id = "+req.params.id+"&nbsp; </mark>");
                }else {
                res.header("Content-Type",'application/json');
                res.send(JSON.stringify(result[0], null, 4));
                // res.json(result);
            }  */
            // return (result);
            resolve(result);
        });
     });        
    
}


module.exports = {
    getUserById
}

