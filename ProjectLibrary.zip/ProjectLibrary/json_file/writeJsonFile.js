
var fs = require('fs');
var path = require('path');

var books =[
  {
    bname: 'Introduction to Agile Methodology',
    author: 'E. Warren',
    genre: 'Textbook',
    bookcount: '2'
  },
  {
    bname: 'Elon Musk: Tesla, SpaceX, and the Quest for a Fantastic Future',
    author: 'Elon Musk',
    genre: 'Technology',
    bookcount: '5'
  },
  {
    bname: 'Beginning Node. js',
    author: 'Basarat Syed',
    genre: 'Technology',
    bookcount: '5'
  },
  {
    bname: 'Web Development with Node and Express',
    author: 'Ethan Brown',
    genre: 'Technology',
    bookcount: '3'
  }
];

//creating book.json file



var readBook = fs.readFile('books.json', 'utf8', function(err, data){
  if(err) throw err;
  console.log(data);
});

//books.push()

fs.writeFile("books.json",JSON.stringify(books), function(err){
    if(err) throw err;
    console.log('data written to file successfully');
});

fs.appendFile("new.txt","appended string ", (err)=>{
  console.log("data appended ");
} )