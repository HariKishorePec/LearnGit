
const bodyParser = require('body-parser');
const mysql = require('mysql');
var urlendcodedParser = bodyParser.urlencoded({ extended: true });

var con = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'Root1234',
    database: 'libraryDB'
});

con.connect((err)=>{
    // if(err) throw err;
    if(err) console.dir("ERROR: Couldnt connect to db-- "+err.message);
    else console.dir("Connected to Database...")
});

/* var users = [
    {
        fname: 'Hari kishore',
        city: 'chennai',
        contact: '23424 23423',
        emailid: 'harikishore@adp.com'
    },
    {
        fname: 'Hari',
        city: 'Pondicherry',
        contact: '98654 65432',
        emailid: 'harikishore@pec.edu'
    },
    {
        fname: 'Revanth',
        city: 'CHENNAI',
        contact: '12345 65487',
        emailid: 'revanth.pec@gmail.com'
    }
]; */


function userHomeGet(req, res){
    res.render('home');
    console.log('Get request for /');
}

function addUserPost(req, res) {
    console.log(req.body);
    console.log('POST request for /adduser');
    
    // users.push(req.body);
    /* Adding record to database */
    let sql = 'INSERT INTO users SET ?';
    let query = con.query(sql, req.body, (err, results)=>{
        if(err){
             if(err.code === 'ER_DUP_ENTRY'){
                let message = 'The Email you entered already exists.';
                console.dir(message);
                
                res.render('adduser',{message});
            }
            else throw err;
        }
        else{
            
            console.dir("Successfully inserted.");
            console.log(results);
            res.render('adduser_success', { data: req.body });
        }
    });
    
}

function addUserGet(req, res) {
    res.render('adduser', {message:""});
    console.log('Get request for /adduser');
}

function viewUserGet(req, res) {
    //fetching user from database
    let sql = 'SELECT * FROM users';
    var query = con.query(sql, (err,results)=>{
        console.log('Get request for /viewuser');
        console.log(results);
        console.log(results[0].fname);

        res.render('viewuser', { allusers: results });
    });
    // res.render('viewuser', { allusers: users });
    // console.log('Get request for /viewuser');
    // console.log(users);
}

function updateUserGet(req, res) {
    usr = [];
    /*  users.forEach((user) => {  //find user from users array (not from db)
        usr.push(user['emailid']);
    });  */
    
    //finding user from DATAbase
    let sql = 'SELECT emailid FROM users';
    var query = con.query(sql, (err, results)=>{
        console.log(results);
         results.forEach((user_email)=>{        //user_email -- is an object {emailid: 'harikishore@gmail.com' }
            usr.push(user_email.emailid);
        }); 
         /*  for(var i =0; i< results.length;i++){
            usr.push(results[i]);
        }   */
        console.log("usr =", usr);
        res.render('updateuser', { availableUsers: usr })
    });
    
    /*console.log(" usr =", usr);
    res.render('upda teuser', { availableUsers: usr }) */
}

function updateUserPost(req, res) {
    console.log('POST request for /updateuser')
    //update user in array 
    tempObj = {};
    /*     users.forEach(function (userObj) {
        if (userObj.emailid == req.body.emailid) {
            //user found
            console.log('user found: ' + JSON.stringify(userObj)); //can send data to client directly from here too..
            //change users details with new ones
            // tempObj = userObj; //shallow copy
            tempObj = JSON.parse(JSON.stringify(userObj)); //deep copy
            userObj.city = req.body.city;
            userObj.contact = req.body.contact;
            userObj.fname = req.body.fname;
            console.log("details changed successfully.")
        }
    }); */

    //update user in DB where emailid = req.body.emailid

    //   #1- getting old data

    let sql1 = `SELECT * FROM users WHERE emailid='${req.body.emailid}' `;
    con.query(sql1, (err, oldresults)=>{
        if(err) throw err; 
        console.dir("Old data:");
        console.log(oldresults);
        tempObj = JSON.parse(JSON.stringify(oldresults[0]));
    })
    //   #2- setting new data
    let sql = `UPDATE users SET fname='${req.body.fname}', city='${req.body.city}', contact='${req.body.contact}' WHERE emailid='${req.body.emailid}' `;

    con.query(sql, (err, result)=>{
        if(err) throw err;
         console.dir("updation success");
         console.log(result);
         res.render('updateuser_success', { olddata: tempObj, newdata: req.body });
    });

    console.log("details changed successfully.")

    
    // res.render('updateuser_success', { olddata: tempObj, newdata: req.body });    //since result page is same as adduser_success
}

function findUserGet(req, res) {
    /* find user from db/array where fname=req.query.param */

    var data = {};    
    console.log('request for finding user: ' + req.params.emailid);

    //finding user from array
    /*     usrIndex = -1;
     users.forEach(function (userObj) {
        if (userObj.emailid == req.params.emailid) {
            //user found
            console.log('user found: ' + JSON.stringify(userObj)); //can send data to client directly from here too..
            usrIndex = users.indexOf(userObj);
        }
    });
    data = users[usrIndex];    */
  
    // finding user from database
    let sql = `SELECT fname, city, contact FROM users WHERE emailid='${req.params.emailid}' `; //city -> cidy //for error check
    let query = con.query(sql, (err, results)=>{
        if(err) throw err;       //make comment this -> if not thrown explicitly, its not thrown
        console.dir("RESULTS----");
        console.log(results);
        res.json(results[0]);       //its returned as array
    });
    // console.log("data sent to client: " + data);
    // res.json(data);
}

function deleteUserGet(req, res){
    res.render('deleteuser', {message : " " });
}

function deleteUserPost(req, res){
    console.log("/delete user POST request..");
    console.log(req.body);
    let sql  =  `DELETE FROM users WHERE emailid='${req.body.email}'`;
    con.query(sql, (err, result)=>{
        if(err){
            console.dir("ERROR: "+err.message);
            res.render('deleteuser', {message : err.code });
        }
        else{
            if(result.affectedRows !== 0){
            res.render('deleteuser_success', { message : "User Successfully Deleted.", email:req.body.email });
            console.log(result);
            }else{
                console.log("Query OK, But No user deleted.");
                res.render('deleteuser', {message : `The email '${req.body.email}' doesnt exist. Please check again.` });
            }
        }
    });
    
}



// module.exports.users = users;

module.exports = {
    userHomeGet,
    addUserPost,
    addUserGet,
    viewUserGet,
    updateUserGet,
    updateUserPost,
    findUserGet,
    deleteUserGet,
    deleteUserPost
} 