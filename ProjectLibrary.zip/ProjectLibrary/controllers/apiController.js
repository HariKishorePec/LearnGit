const mysql = require('mysql');
const express = require('express');
const userServices = require('../services/user.js');

var app = express();

// app.set('json spaces', 2);

var con = mysql.createConnection({
    host:'localhost',
    port:'3306',
    user:'root',
    password:'Root1234',
    database:'libraryDB'
});

con.connect((err)=>{
    // if(err) throw err;
    if(err) console.dir("ERROR: Couldnt connect to db-- "+err.message);
    else console.dir("Connected to Database...")
});

/* module.exports = function(app){

    app.get('/api', APIgetRoot);

    app.get('/api/books', APIgetBook);

    app.get('/api/books/:id', APIgetBookId);

    app.get('/api/books/genre/:genre', APIgetBookGenre);

    app.get('/api/authors', APIgetAuthors);

    app.get('/api/users', APIgetUsers);

    app.get('/api/users/:id', APIgetUsersId);

    app.get('/api/issuedbook/', APIgetIssuedBook);

    app.get('/api/issuedbook/:userid', APIgetIssuedBookUser);

    //  app.listen('5000', ()=>{     //required only when this is run using node command at terminal
    //     console.log("listening on port 5000..");
    // }) 
    
} */

//ok
function APIgetBook (req,res){
    /* var temp = [{"id":1,"bname":"first book","author":"new author","genre":"no genre","bookcount":30},{"id":2,"bname":"new book","author":"second author","genre":" genre 1","bookcount":25}]; */
    let sql = "SELECT * from books";
    let query = con.query(sql, (err, results)=>{
        console.log("result: books fetched from database and sent to client");
        // res.json(results);
        res.header("Content-Type",'application/json');
        res.send(JSON.stringify(results, null, 4));
    }); 

    // res.json(temp);
}

//ok
function APIgetBookId(req,res){
    let sql = `SELECT * from books WHERE id='${ req.params.id}'`;
    let query = con.query(sql, (err, result)=>{
        console.log("result: books fetched from database and sent to client");
        console.dir("Total records fetched: "+result.length);
        if(result.length === 0){
            res.send("No any book exists with <mark> &nbsp; id = "+req.params.id+"&nbsp; </mark>");
        }else {
            res.header("Content-Type",'application/json');
            res.send(JSON.stringify(result[0], null, 4));
            // res.json(result);
        }            
    });
}

//ok
function APIgetBookGenre(req,res){
    let sql = `SELECT * from books WHERE genre='${ req.params.genre}'`;
    let query = con.query(sql, (err, result)=>{
        console.log("result: books fetched from database and sent to client");
        console.dir("Total records fetched: "+result.length);
        if(result.length === 0){
            res.send("No any book exists with <mark> &nbsp; genre= "+req.params.genre+"&nbsp; </mark>");
        }else {
            res.header("Content-Type",'application/json');
            res.send(JSON.stringify(result, null, 4));
            // res.json(result);
        }            
    });
}

//ok
function APIgetAuthors(req,res){
    let sql = "SELECT author FROM books";
    con.query(sql, (err, results)=>{
        if(err) console.dir("ERROR-- "+err.message);
        else{
            console.log("RESULT-- ", results);
            res.header({'Content-Type':'Application/json'});
            res.send( JSON.stringify( results, null, 4));
        }
    })
}

//ok
function APIgetUsers(req,res){
    let sql = "SELECT * from users";
    let query = con.query(sql, (err, results)=>{
        console.log("RESULT: users fetched from database and sent to client");
        // res.json(results);
        res.header("Content-Type",'application/json');
        res.send(JSON.stringify(results, null, 4));
    }); 
}

//ok
async function APIgetUsersId(req,res){
    try{
        const {id: userId} = req.params;    //destructuring objects
        // const user = await getUserById(userId);
        const result = await userServices.getUserById(userId);
        // await someFunction(user);
        if(result.length === 0){
            // res.send("No any USER exists with <mark> &nbsp; id = "+req.params.id+"&nbsp; </mark>");      //commented for testing purpose
            res.send("No USER exist with given id");
        }else {
            res.header("Content-Type",'application/json');
            res.send(JSON.stringify(result[0], null, 4));
            // res.json(result);
        } 
    }catch (err) {
        console.dir("ERROR: "+err);
        return (err);
    }  
}



//ok
function APIgetIssuedBook(req,res){
    //get all books issued to user with id = x
    /*     let sql = "SELECT u.id, u.fname, b.id, b.bname FROM users u INNER JOIN book_issue bi ON u.id=bi.userid INNER JOIN books b ON b.id=bi.bookid"; */
    let sql = "SELECT bi.id as `Issue ID`, u.id as `User ID`, u.fname as `User Name`, b.id as `Book ID`, b.bname as `Book title` FROM book_issue bi LEFT JOIN users u ON bi.userid=u.id LEFT JOIN books b ON bi.bookid=b.id";
    con.query(sql, (err, results)=>{
        if (err) throw err;
        else{
            console.dir('Issued book to the user fetched and sent to client.');
            console.log(results);
            res.header({'Content-Type':'Application/json'});
            res.send(JSON.stringify(results, null, 4));
        }
    })
}

//ok
function APIgetIssuedBookUser(req,res){
    let userid = req.params.userid;
    //get all books issued to user with id = x
    /*     let sql = "SELECT u.id, u.fname, b.id, b.bname FROM users u INNER JOIN book_issue bi ON u.id=bi.userid INNER JOIN books b ON b.id=bi.bookid"; */
    let sql = "SELECT bi.id as `Issue ID`, u.id as `User ID`, u.fname as `User Name`, b.id as `Book ID`, b.bname as `Book Title` FROM book_issue bi LEFT JOIN users u ON bi.userid=u.id LEFT JOIN books b ON bi.bookid=b.id WHERE u.id = '"+ userid +"' ";
    con.query(sql, (err, results)=>{
        if (err) throw err;
        else{
            if(results.length === 0){
                console.dir("No book has been issued for the userid -- "+userid);
                res.send("No book has been issued to user with <mark> &nbsp; userid = "+userid+"&nbsp; </mark>");
            }
            else{
                console.dir('Issued book to the user fetched and sent to client.');
                console.log(results);
                res.header({'Content-Type':'Application/json'});
                // res.send("Total Results: "+results.length); //both send wont work, in express.
                res.send(JSON.stringify(results, null, 4));
            }
           
        }
    })
}

//ok
function APIgetRoot (req,res){
    console.log('api request recieved.');
    res.send('You are on root api. Use appropriate API from <a href="/">home screen..</a>');
}



module.exports ={
    APIgetBook,
    APIgetBookId,
    APIgetBookGenre,
    APIgetAuthors,
    APIgetUsers,
    APIgetUsersId,
    APIgetIssuedBook,
    APIgetIssuedBookUser,
    APIgetRoot
}