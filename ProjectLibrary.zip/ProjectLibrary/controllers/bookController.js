var fs = require('fs');
const bodyParser = require('body-parser');
var usrCtrl = require('./usersController.js');
var mysql =require('mysql');

//storing books to array
var books=[];

//for storing books to database
var con = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'Root1234',
    database: 'libraryDB'
});

function refreshBook(){  //populate the book object with updated details of book from file.
    fs.readFile('./books.json', 'utf8', function(err, BooksFromFile){
      if(err) throw err;
      console.log("data read from book.json success..");
      // console.log(BooksFromFile);
      books=JSON.parse(BooksFromFile);
    });
}

refreshBook();
console.log(typeof(books));

var urlendcodedParser = bodyParser.urlencoded({extended:true});


//ok
function addBookGet (req,res){
    res.render('addbook', {data: req.body});
    console.log('Get request for /addbook');
}

//ok
function addBookPost(req,res){
    res.render('addbook_success', {data: req.body});
    console.log('POST request for /addbook');
    /* books.push(req.body); //instead directly writing to file -- wont work, so reverting
    fs.writeFile('./books.json', JSON.stringify(books), (err)=>{
      console.log("Book details added to file..");
    }) */

    /* Adding record to database */
    let sql = 'INSERT INTO books SET ?';
    let query = con.query(sql, req.body, (err, results)=>{
        if(err) throw err;
        console.dir("Book details Successfully inserted into DB");
        console.log(results);
    });
    console.log(req.body);
}

//ok
function viewBookGet (req,res){
    console.log('Get request for /viewbook');
   /*  refreshBook();
    res.render('viewbook', {allbooks: books});      //fetch books from books.json
     */

    //fetching books from database
    let sql = "SELECT * FROM books";
    let query = con.query(sql, (err, results)=>{
        if(err) console.dir("ERROR: "+err.message);
        console.log(results);
        res.render('viewbook', {allbooks: results});
    })
   
}

//ok - array
function find_bookGet2 (req, res){
    //used in extensiveSearch.ejs
    // for search in array/books.json file
    console.log("GET request at find_book/"+req.params.phrase);
    var sendBook=[];
    books.forEach(function(bookObj) {
      var fullBookName = bookObj.bname.toLowerCase();
      var phrase = req.params.phrase;
      var result = fullBookName.includes(phrase.toLowerCase());
      if( result){
          // console.log("book found");
          // sendBook.push(fullBookName); 
          sendBook.push(bookObj.bname);   //to retain font case of bookname, e.g. not force to lowercase.
      }
    });
    // res.json( JSON.stringify(sendBook));
    res.send(sendBook);
    console.log("book sent: "+sendBook);
}

//ok - DB
function find_bookGet(req, res){
    console.log("GET request at find_book/"+req.params.phrase);
    var sendBook=[];
    let sql = `SELECT bname from books WHERE bname LIKE '%${ req.params.phrase }%'`;
    let query = con.query(sql, (err, results)=>{
        if (err) console.dir("ERROR: "+err.message);
        if (err) throw err;
        console.log(results);
        results.forEach(function(bnameObj){
            sendBook.push(bnameObj.bname);
        });
        res.send(sendBook);
        console.log("book sent: "+sendBook);
    });
}

//ok - array
function issueBookGet2 (req,res){
    /* This function fetched data from storage(arrays/books.json here) and populates front end combobox */
    availableBook=[];
    availableUsers=[];
    books.forEach((book)=>{
        availableBook.push(book['bname']);
        //.push({id:book['id'], bname:book['bname']})
    });
    usrCtrl.users.forEach((usr)=>{
        availableUsers.push(usr['fname']);
    });
    res.render('issuebook', {availableBook: availableBook, availableUsers});
    console.log(availableBook);
    console.log(usrCtrl.users);
    console.log('Get request for /issuebook');
}

//ok
function issueBookGet (req, res){
    /* This function fetched data from storage(DATABASE here) and populates front end combobox */
    availableBook=[];
    availableUsers=[];
    let sql = "SELECT bname FROM books";            
    let sql2 = "SELECT emailid FROM users";
    /* 
    let promise1 = new Promise( function(resolve, reject){

        //task1
        con.query(sql, (err, resultBooks)=>{
            // if(err ) throw err;
            if(err) reject(err);
            console.log("Books fetched..");
            console.dir(resultBooks);
            resultBooks.forEach(function(book){
                availableBook.push(book.bname);
            })
        });

        //task2
        con.query(sql2, (err, resultUsers)=>{
            // if(err ) throw err;
            if(err) reject(err);
            console.log("users fetched..");
            console.dir(resultUsers);
            resultUsers.forEach(function(user){
                availableUsers.push(user.emailid);
            })
        });

        resolve('success');

    });
    */
    /* promise1.then((message)=>{
        res.render('issuebook', {availableBook: availableBook, availableUsers});
        console.log("availableBook= "+availableBook);
        console.log("availableUsers= "+availableUsers);
        console.log("data sent success..");
        }).catch((errMessage)=>{
        console.log("ERROR:(from promises) -- "+errMessage);
    }); 
    */
    con.query(sql, (err, resultBooks)=>{
        //1st task
        if(err ) throw err;
        console.log("Books fetched..");
        console.dir(resultBooks);
        resultBooks.forEach(function(book){
            availableBook.push(book.bname);
        });

        //2nd task //on completion of first
        con.query(sql2, (err, resultUsers)=>{
            // if(err ) throw err;
            if(err) reject(err);
            console.log("users fetched..");
            console.dir(resultUsers);
            resultUsers.forEach(function(user){
                availableUsers.push(user.emailid);
            });

            //then 3rd task
            res.render('issuebook', {availableBook: availableBook, availableUsers});
            console.log("\navailableBook= "+availableBook);
            console.log("\navailableUsers= "+availableUsers);
            console.log("data sent success..");
        });   
        
    });
}
 
//ok - array
function searchBookPost2 (req,res){
    /* This methods works for array/file reading */
    refreshBook();
    console.log("Search request for book ", req.body);
    var queryBook = req.body.bname;
    var searchOption = req.body.searchby;
    console.log(searchOption);
    // var fruits = ["Banana", "Orange", "Apple", "Mango", "Banana", "Orange", "Apple"];
    // var a = fruits.indexOf("Apple");
    var messageStr;
    var bookIndex = -1;
    if(searchOption == "booktitle"){
      books.forEach(function(bookObj) {
        if(bookObj.bname == queryBook){
            messageStr = "Book Found";
            bookIndex = books.indexOf(bookObj);
        }
      });
    } 
    else if(searchOption == "author"){
      books.forEach(function(bookObj) {
        if(bookObj.author == queryBook){
            messageStr = "Book Found";
            bookIndex = books.indexOf(bookObj);
        }
      });
    }

    var foundBook = books[bookIndex];

    console.log(foundBook);
    if(bookIndex ==-1){
      messageStr = "No Such Book Found!!";
    }
    res.render('searchbook', { errorFlag: 1, message:messageStr, foundBook:foundBook});

    // console.log(books);
}

//ok
function searchBookPost (req, res){
    /* This methods works for DB reading */
    console.log("Search request for book ", req.body);
    var queryBook = req.body.bname;
    var searchOption = req.body.searchby;
    console.log("Search in DB by-- "+searchOption+ " for book "+queryBook);
    var messageStr="No Such Book Found!!";

    let sql;
    if(searchOption === 'booktitle'){
        sql = `SELECT * FROM books WHERE bname = '${queryBook}' `;
    }else if (searchOption === 'author'){
        sql = `SELECT * FROM books WHERE author = '${queryBook}'` 
    }

    let query = con.query(sql, (err, result)=>{
        if (err) console.dir("ERROR: "+ err.message);
        else {
            messageStr = 'Book Found'; 
            console.log(messageStr);
            console.dir(result);
            res.render('searchbook', { errorFlag: 1, message:messageStr, foundBook:result[0]}); 
        }
                
    });
}

//ok -array   //better done in /api/books
function searchbook_getGet (req,res){
    refreshBook();
    /* res.render('searchbook', { errorFlag: 0 });
    console.log('Get request for /searchbook');
    // console.log(books); */
    /* --------------------- searching using get request/ url params -------------------------- */
    console.log("Search request for book ", req.body);
    var queryBook = req.query.bname;
    var searchOption = req.query.searchby;
    console.log(searchOption);
    // var fruits = ["Banana", "Orange", "Apple", "Mango", "Banana", "Orange", "Apple"];
    // var a = fruits.indexOf("Apple");
    var messageStr;
    var bookIndex = -1;
    if(searchOption == "booktitle"){
        books.forEach(function(bookObj) {
        if(bookObj.bname == queryBook){
            messageStr = "Book Found";
            bookIndex = books.indexOf(bookObj);
        }
        });
    } 
    else if(searchOption == "author"){
        books.forEach(function(bookObj) {
        if(bookObj.author == queryBook){
            messageStr = "Book Found";
            bookIndex = books.indexOf(bookObj);
        }
        });
    }
    
    var foundBook = books[bookIndex];

    console.log(foundBook);
    if(bookIndex ==-1){
        messageStr = "No Such Book Found!!";
    }
    res.render('searchbook_get', { errorFlag: 1, message:messageStr, foundBook:foundBook});
}

//ok
function issueBookPost (req,res){
    console.log('Request for /IssueBookPost ');
    console.log(req.body);

    // sample data
    /* var issuedbook = {
        bname: 'Web Development with Node and Express',
        user: 'hari@gmail.com'
    }; */

    // let sql = `INSERT INTO book_issue VALUES( null, 1, 1) `;     //(id int AUTO_INCREMENT , bookid int, userid int)
    let sql = `INSERT INTO book_issue VALUES( null, (select id from books where bname='${req.body.bname}'), (select id from users where emailid='${req.body.user}') ); `;

    console.dir("SQL-- " +sql);
    //taks1
    let query = con.query(sql, (err, result)=>{
        if(err) throw err;
        console.log("issued book add to book_issue table successfully.");
        console.log(result);
        //then task2
        let sql2 = `update books set bookcount=bookcount-1 where id='(select id from books where bname='${req.body.bname}')'`;
        con.query(sql2, (err, result)=>{
            console.dir("SQL2-- "+sql2);
            console.log("Updated bookcount(-1).");
            
            //then task 3
            res.render('issuebook_success', { data: req.body});
        });
    }); 

}

//ok
function showIssuedBookGet (req,res){
    // let sql = "SELECT * FROM book_issue";
    let sql = `select bi.* , u.fname, b.bname from book_issue bi LEFT JOIN users u ON bi.userid=u.id LEFT JOIN books b ON bi.bookid=b.id;`;
    con.query(sql, (err, results)=>{
        if(err) console.dir("ERROR: "+err.message);
        else{
            console.dir("RESULTS -- ");
            console.log(results);
            res.render('showIssuedBook', {issuedBookDetails: results});
        }
    });    
}

function extensiveSearchGet (req, res){
    res.render('extensiveSearch', {initialRequest: true});
}

function searchBookGet(req,res){
    res.render('searchbook', { errorFlag: 0});
}

module.exports = {
    addBookGet,
    addBookPost,
    viewBookGet,
    searchBookGet,
    searchbook_getGet,
    searchBookPost,
    issueBookGet,
    issueBookPost,
    extensiveSearchGet,
    find_bookGet,
    showIssuedBookGet    
}