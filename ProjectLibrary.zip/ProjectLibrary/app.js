var express = require('express');
var ejs = require('ejs');

var userController = require('./controllers/usersController');
var bookController = require('./controllers/bookController');
var apiController = require('./controllers/apiController');

var api_routes = require('./routes/api_routes');
var users_routes = require('./routes/users_routes');
var books_routes = require('./routes/books_routes');

var app = express();

app.set('view engine', 'ejs');

app.use('/', express.static('public'));

// userController(app);
// bookController(app);
// apiController(app);

api_routes(app);
users_routes(app);
books_routes(app);

app.listen(5000);
console.log("Server started on port 5000...");