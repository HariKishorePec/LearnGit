'use strict';

const expect = require('chai').expect;
const assert = require('chai').assert;
const apiController = require('../controllers/apiController');
const http = require('http');
const axios = require('axios');
const sinon = require('sinon');
const sinonChai = require('sinon-chai'); 
const chai = require('chai');
chai.use(sinonChai);

describe('API controller ', function(){

    /*before(()=>{
        sinon.stub(console, 'log');     //supressing console.log
    }); */
    context('APIgetUsersId()', function(){

        // const expected = {
        //     id, 
        //     fname,
        //     city,
        //     contact,
        //     emailid
        // };
        const greet = "hello";
        
        /* it('returns a user with id provided',  function(){
            // expect(apiController.APIgetUsersId(1)).to.equal(expected);
            expect(apiController.APIgetUsersId(3)).to.have.property('id');
            expect(apiController.APIgetUsersId(3)).to.have.property('fname');
            expect(apiController.APIgetUsersId(3)).to.have.property('city');
            expect(apiController.APIgetUsersId(3)).to.have.property('contact');
            expect(apiController.APIgetUsersId(3)).to.have.property('emailid');
            // assert.equal()

        }); */

     

        it('should return hello', function(){
            const name = 'hello';
            expect(name).to.equal(greet);
        });
       
         context('with provided user id', function(){
            it('should return an object', function(){

                const expected = {
                    id:null, 
                    fname:null,
                    city:null,
                    contact:null,
                    emailid:null
                }
                const url = "http://localhost:5000/api/users/5";
                /* 
                    const response = http.get(url, (res)=>{
                        console.log('fetched http response in controller test');
                        console.dir("Status Code: "+res.statusCode);
                    }); 
                */
            
                axios.get(url)
                .then(response => {
                    // console.dir("Status code: "+ response.status );
                    // console.log(response.data);
                    let result = response.data;
                    // expect(response.data ).to.equal(expected);
                    expect( result ).to.have.property('id');
                    expect( result).to.have.property('fname');
                    expect( result ).to.have.property('city');
                    expect( result ).to.have.property('contact');
                    expect( result ).to.have.property('emailid'); 
                })
                .catch(error => {
                    console.log(error.code);
                    // expect(error).to.not.exist;
                });
                // const result = apiController.APIgetUsersId()  //ERROR: TypeError: Cannot read property 'params' of undefined
                // expect(result).to.deep.equal(expected);
            });
        }); 

        context('With ID/userid provided, if user doesnt exist',function(){
            it('should return "No USER exist with given id"',function(){
                const url = "http://localhost:5000/api/users/55";
                axios.get(url)
                .then(response => {
                    // console.dir("Status code: "+ response.status );
                    // console.log(response.data);
                    let result = response.data;
                    expect(result).to.equal("No USER exist with given id");
                })
                .catch(error => {
                    console.log(error);
                }); 

                // let result = apiController.APIgetUsersId
            });
        });
        
    });
});