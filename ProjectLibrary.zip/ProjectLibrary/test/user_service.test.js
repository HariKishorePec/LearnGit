'use strict';

const expect = require('chai').expect;
const assert = require('chai').assert;
const userService = require('../services/user');


describe('/services/user.js ', function(){

    describe('getUsersId()', function(){

 /*        const expected = {
            id, 
            fname,
            city,
            contact,
            emailid
        }; */
        const greet = "hello";
        
/*         it('should return an similar object type');

        it('object should exist', async function(){
            const  result  = await userService.getUserById(3);
            expect(result[0]).to.exist;
                        
        });
 */
        it('should have a property id', async function(){
            const  result  = await userService.getUserById(3);
            expect(result[0]).to.have.property('id');
        });

        it('returns a user with id provided',async function(){

            const  result  = await userService.getUserById(3);
            // expect(apiController.APIgetUsersId(1)).to.equal(expected);
            expect(result[0]).to.have.property('id');
            expect( result[0]).to.have.property('fname');
            expect( result[0] ).to.have.property('city');
            expect( result[0] ).to.have.property('contact');
            expect( result[0] ).to.have.property('emailid');
            // assert.equal()

        });

        it('should return hello', function(){
            const name = 'hello';
            expect(name).to.equal(greet);
        });

        it('id should be of type number', async function(){
            const  result  = await userService.getUserById(3);
            const { id } = result[0];
            expect(id).to.be.a('number');
        });  
    });
});