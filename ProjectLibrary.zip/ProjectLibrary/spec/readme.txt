spec -- for testing

service testing? or controller's testing

Happy path,
failure path.