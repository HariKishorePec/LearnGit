
const express = require('express');

const bodyParser = require('body-parser');
var urlendcodedParser = bodyParser.urlencoded({ extended: true });

var app = express();

var userController = require('../controllers/usersController');

module.exports = function (app) {

    // app.use(bodyParser); //depreciated.
    // var urlendcodedParser = bodyParser.urlencoded({extended:true});  //doesnot work here.- keep as global

    app.get('/', userController.userHomeGet);

    app.get('/adduser', userController.addUserGet);

    app.get('/deleteuser', userController.deleteUserGet);

    app.post('/deleteuser', urlendcodedParser, userController.deleteUserPost);

    app.get('/viewuser', userController.viewUserGet);

    app.post('/adduser', urlendcodedParser, userController.addUserPost);

    app.get('/updateuser', userController.updateUserGet);

    app.post('/updateuser', urlendcodedParser, userController.updateUserPost);

    app.get('/finduser/:emailid', userController.findUserGet);
}
