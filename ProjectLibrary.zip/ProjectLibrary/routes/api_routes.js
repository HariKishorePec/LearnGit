const express = require('express');

var app = express();

var apiController = require('../controllers/apiController');

module.exports = function(app){

    app.get('/api', apiController.APIgetRoot);

    app.get('/api/books', apiController.APIgetBook);

    app.get('/api/books/:id', apiController.APIgetBookId);

    app.get('/api/books/genre/:genre', apiController.APIgetBookGenre);

    app.get('/api/authors', apiController.APIgetAuthors);

    app.get('/api/users', apiController.APIgetUsers);

    app.get('/api/users/:id', apiController.APIgetUsersId);

    app.get('/api/issuedbook/', apiController.APIgetIssuedBook);

    app.get('/api/issuedbook/:userid', apiController.APIgetIssuedBookUser);

    /*app.listen('5000', ()=>{     //required only when this is run using node command at terminal
        console.log("listening on port 5000..");
    }) */
    
}