const express = require('express');
const bodyParser = require('body-parser');
var bookController = require('../controllers/bookController');

var app = express();


var urlendcodedParser = bodyParser.urlencoded({extended:true});

module.exports = function(app){

    // app.use(bodyParser); //depreciated.
    // var urlendcodedParser = bodyParser.urlencoded({extended:true});  //doesnot work here.- keep as global

    app.get('/addbook', bookController.addBookGet);

    app.post('/addbook', urlendcodedParser, bookController.addBookPost);
    
    app.get('/viewbook', bookController.viewBookGet);

    app.get('/searchbook', bookController.searchBookGet);

    app.get('/searchbook_get', bookController.searchbook_getGet);

    app.post('/searchbook', urlendcodedParser, bookController.searchBookPost);
    
    app.get('/issuebook', bookController.issueBookGet);

    app.post('/issuebook', urlendcodedParser, bookController.issueBookPost);

    app.get('/extensiveSearch', bookController.extensiveSearchGet);

    app.get('/find_book/:phrase', bookController.find_bookGet);

    app.get('/showIssuedBook', bookController.showIssuedBookGet);
}